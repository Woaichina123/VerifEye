const DEEPSEEK_API_KEY = "sk-0afbe82fd0a24dc6af9d9ce3da278f2b";

window.verifeyeDeepSeekAnalyze = async function(title, bodyText) {
  try {
    const prompt = `请你作为信息安全与事实核查专家，判断以下网页内容的真实性和可信度，并用100分制评分，分数越高越可信。请用简洁中文说明理由。\n标题：${title}\n正文：${bodyText.slice(0, 1000)}\n\n请以如下JSON格式输出：{\"score\":分数,\"analysis\":\"简要分析\"}`;
    const resp = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [
          { role: "user", content: prompt }
        ]
      })
    });
    const data = await resp.json();
    let result = { score: 60, analysis: "AI分析失败" };
    if (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) {
      try {
        // 解析AI返回的JSON
        result = JSON.parse(data.choices[0].message.content.replace(/```json|```/g, '').trim());
      } catch (e) {
        result = { score: 60, analysis: data.choices[0].message.content };
      }
    }
    if (typeof result.score !== 'number') result.score = 60;
    if (typeof result.analysis !== 'string') result.analysis = 'AI分析失败';
    return result;
  } catch (e) {
    return { score: 60, analysis: "AI分析异常" };
  }
}; 