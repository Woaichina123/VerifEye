console.log('VerifEye content.js loaded!');
// 提取网页正文和标题
function extractMainContent() {
  const title = document.title;
  let bodyText = '';
  if (document.body) {
    bodyText = document.body.innerText || '';
  }
  return { title, bodyText };
}

// 创建悬浮窗，支持自定义初始内容
function createFloatingWindow(initialText = '分析中...', initialColor = '#ccc', detailText = '正在分析网页内容，请稍候...') {
  let win = document.getElementById('verifeye-floating-window');
  if (!win) {
    win = document.createElement('div');
    win.id = 'verifeye-floating-window';
    win.className = 'verifeye-floating-window';
    document.body.appendChild(win);
  }
  win.innerHTML = `
    <div class="verifeye-score-bar">
      <span id="verifeye-score-value">${initialText}</span>
    </div>
    <div id="verifeye-detail" style="display:none;">${detailText}</div>
  `;
  win.style.background = initialColor;
  win.onclick = () => {
    const detail = document.getElementById('verifeye-detail');
    if (detail) detail.style.display = detail.style.display === 'none' ? 'block' : 'none';
  };
}

// 更新悬浮窗分数和颜色
function updateFloatingWindow(score, color, detailHtml) {
  const scoreValue = document.getElementById('verifeye-score-value');
  const win = document.getElementById('verifeye-floating-window');
  const detail = document.getElementById('verifeye-detail');
  if (scoreValue && win && detail) {
    scoreValue.innerText = typeof score === 'number' ? `可信度：${score}分` : score;
    win.style.background = color;
    detail.innerHTML = detailHtml;
  }
}

(async function main() {
  console.log('VerifEye content.js loaded!');
  // 1. 初始只显示“分析中...”，不显示分数
  createFloatingWindow();

  const { title, bodyText } = extractMainContent();
  const url = window.location.href;

  let phishingResult = null;
  let aiResult = null;
  let errorMsg = '';

  // 2. 钓鱼检测
  try {
    phishingResult = await window.verifeyePhishingCheck(url);
  } catch (e) {
    phishingResult = null;
    errorMsg += '钓鱼检测失败；';
  }

  // 3. AI分析
  try {
    aiResult = await window.verifeyeDeepSeekAnalyze(title, bodyText);
  } catch (e) {
    aiResult = null;
    errorMsg += 'AI分析失败；';
  }

  // 4. 结果处理
  if (phishingResult && aiResult) {
    let finalScore = aiResult.score;
    let color = '#4caf50'; // 绿
    if (!phishingResult.safe) {
      finalScore = Math.min(finalScore, 30);
      color = '#f44336'; // 红
    } else if (finalScore < 60) {
      color = '#f44336'; // 红
    } else if (finalScore < 80) {
      color = '#ff9800'; // 黄
    }
    updateFloatingWindow(
      finalScore,
      color,
      `<b>钓鱼检测：</b> ${phishingResult.safe ? '安全' : '可疑'}<br/>${phishingResult.reason}<br/><b>AI分析：</b><br/>${aiResult.analysis}`
    );
  } else {
    // 检测失败
    updateFloatingWindow(
      '检测失败',
      '#f44336',
      `<b>检测服务异常：</b><br/>${errorMsg || '请检查网络或API Key'}<br/>`
    );
  }
})();

// window.verifeyePhishingCheck(url)
// window.verifeyeDeepSeekAnalyze(title, bodyText) 