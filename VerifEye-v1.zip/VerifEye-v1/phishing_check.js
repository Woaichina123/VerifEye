const GSB_API_KEY = "AIzaSyAgx6o7InQszKvnjW9Hek5KgTo2jL6RhIs";

window.verifeyePhishingCheck = async function(url) {
  try {
    const reqBody = {
      client: {
        clientId: "verifeye-plugin",
        clientVersion: "1.0.0"
      },
      threatInfo: {
        threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
        platformTypes: ["ANY_PLATFORM"],
        threatEntryTypes: ["URL"],
        threatEntries: [
          { url }
        ]
      }
    };
    const resp = await fetch(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${GSB_API_KEY}`,
      {
        method: "POST",
        body: JSON.stringify(reqBody),
        headers: { "Content-Type": "application/json" }
      }
    );
    const data = await resp.json();
    if (data && data.matches && data.matches.length > 0) {
      return { safe: false, reason: "检测到可疑或钓鱼风险" };
    }
    return { safe: true, reason: "未检测到钓鱼风险" };
  } catch (e) {
    return { safe: true, reason: "钓鱼检测异常" };
  }
}; 